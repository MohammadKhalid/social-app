<?php

    $db_host = "localhost";
    $db_user = "root";
    $db_pass = "adil";

    $db_name = "login";

    $connection = new mysqli($db_host,$db_user,$db_pass,$db_name);

?>